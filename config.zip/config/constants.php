<?php

/*
|--------------------------------------------------------------------------
| CONSTANT global variable for this application
|--------------------------------------------------------------------------
*/

return [
	//constant start for admin pages
        'ADMIN_MAIL_CREDENCIAL' => 'darshan@mnstechnologies.com',
		'ADMIN_PAGE_DASHBORD' => 'Dashbord',
        'ADMIN_PAGE_FAQ' => 'FAQ |',
        'ADMIN_PAGE_CASE_TYPE' => 'Case Type |',
        'ADMIN_PAGE_COURT_TYPE' => 'Court Type |',
        'ADMIN_PAGE_COURT' => 'Court |',
        'ADMIN_PAGE_CASE_STATUS' => 'Case Status |',
        'ADMIN_PAGE_CASE_JUDGE' => 'Judge |',
        'CLIENT_FOLDER_PATH' => '/upload/profile',
        'CLIENT_PASSWORD_FOR_JR_ADVO' => 'jr.advo@#123',
        'TRIAL_DAY' => '14',
        'INVITATION_TOKEN_HOURS' => '48',
		'BLOG_FOLDER_PATH' => '/images/blog',
		'ADVOCATE_URL'=>'http://www.advocatesdiary.in',
                'LOGO_FOLDER_PATH' => '/upload/logo',
                'FAVICON_FOLDER_PATH' => '/upload/favicon',

];
